package dip.day02.aop.exam01.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;

public class CalcAspect {
	public void before(JoinPoint jp) {
		System.out.println("메서드 호출전");
		Signature sig = jp.getSignature();
		System.out.println("메서드명"+sig.getName());
		Object[] args = jp.getArgs();
		System.out.println("인수갯수:"+args.length);
		for (Object object : args) {
			System.out.println("인수값:"+object);
			
		}
	}
}
