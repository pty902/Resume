package dip.day02.jdbc.exam01;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import dip.day02.jdbc.exam01.dao.BoardDao;

public class Main4_MyBatis {

	public static void main(String[] args) throws SQLException{
		String configLocation = "app.xml";
		ApplicationContext context = 
				new FileSystemXmlApplicationContext(configLocation);
		// DB연결
		SqlSessionFactory factory = context.getBean(SqlSessionFactory.class);
		SqlSession session = factory.openSession();
		// 등록 테스트
		BoardVO vo = new BoardVO(); 
		vo.setTitle("mybatis 테스트");
		vo.setWriter("테스트2");
		vo.setContent("mybatis 테스트중입니다");
		session.insert("insert", vo);
		System.out.println("등록 완료");
		//목록 테스트
//		List<BoardVO> list = session.selectList("list_all");
//		for (BoardVO vo : list) {
//			System.out.println(vo);
//		}
		session.close();
	}//end main

}
