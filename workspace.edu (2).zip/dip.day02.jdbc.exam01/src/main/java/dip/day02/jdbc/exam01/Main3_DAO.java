package dip.day02.jdbc.exam01;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import dip.day02.jdbc.exam01.dao.BoardDao;

public class Main3_DAO {

	public static void main(String[] args) throws SQLException{
		String configLocation = "app.xml";
		ApplicationContext context = 
				new FileSystemXmlApplicationContext(configLocation);
		// DB연결
		BoardDao dao = context.getBean(BoardDao.class);
		// 등록 테스트
//		BoardVO vo = new BoardVO(); 
//		vo.setTitle("dao 테스트");
//		vo.setWriter("테스트1");
//		vo.setContent("dao 테스트중입니다");
//		dao.insert(vo);
//		System.out.println("dao.insert() 성공");
		// 목록 테스트
		List<BoardVO> list = dao.list();
		System.out.println("게시물 목록");
		for (BoardVO vo : list) {
			System.out.println(vo);			
		}//end for
		//검색 테스트
		try {
			BoardVO vo = dao.selectByNo(10);
			System.out.println("찾는 자료:"+vo);
		} catch (Exception e) {
			System.err.println("검색 오류:"+e.getMessage());
		}
	}//end main

}
