package dip.day02.jdbc.exam01.dao;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import dip.day02.jdbc.exam01.BoardVO;

public class BoardDao {

	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void insert(BoardVO vo) {
		String sql="INSERT INTO BOARD(title,writer,content,regdate)";
		sql += "values(?,?,?,now())";
		int ret = jdbcTemplate.update(sql, vo.getTitle(), vo.getWriter(), vo.getContent(), vo.getRegdate());
	}//end inesrt()
	public List<BoardVO> list() {
	RowMapper rowMapper = new BeanPropertyRowMapper<>(BoardVO.class);
	String sql = "SELECT * FROM BOARD ORDER BY no desc";
	List<BoardVO> list = jdbcTemplate.query(sql, rowMapper);
	return list;
	}

	public BoardVO selectByNo(int no) {
		String sql = "SELECT * FROM BOARD WHERE no="+no;
		RowMapper rowMapper = new BeanPropertyRowMapper<>(BoardVO.class);
		BoardVO vo = (BoardVO) jdbcTemplate.queryForObject(sql, rowMapper);
		return vo;
	}
}
