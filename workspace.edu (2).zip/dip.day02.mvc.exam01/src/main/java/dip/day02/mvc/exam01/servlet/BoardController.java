package dip.day02.mvc.exam01.servlet;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BoardController {

	@RequestMapping("/board/insert-form.do")
	public String insert_form() {
		return "/board/insert-form";
	}
}
