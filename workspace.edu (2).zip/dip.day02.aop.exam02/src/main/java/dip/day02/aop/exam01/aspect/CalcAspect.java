package dip.day02.aop.exam01.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
@Component
@Aspect
public class CalcAspect {
//	@Before("execution(* plus(..))")
//	public void before(JoinPoint jp) {
//		System.out.println("메서드 호출전");
//		Signature sig = jp.getSignature();
//		System.out.println("메서드명"+sig.getName());
//		Object[] args = jp.getArgs();
//		System.out.println("인수갯수:"+args.length);
//		for (Object object : args) {
//			System.out.println("인수값:"+object);			
//		}
//	}//end before()
//	@AfterReturning(value="execution(* plus(..))", returning="i")
//	public void afterReturning(JoinPoint jp,Integer i) {
//		Signature sig = jp.getSignature();
//		String name = sig.getName();
//		System.out.println(name+" 메서드 종료 후");
//		System.out.println("반환값: "+i);
//	}
	@Around("execution(* plus(..))")
	public Integer around(ProceedingJoinPoint pjp) throws Throwable {
		long startTime = System.currentTimeMillis();
		Integer ret = (Integer)pjp.proceed(); //타겟 메서드 실행
		long endTime = System.currentTimeMillis();
		System.out.println("실행시간: "+(endTime-startTime)+"ms");
		
		return ret;
	}
}//end class
