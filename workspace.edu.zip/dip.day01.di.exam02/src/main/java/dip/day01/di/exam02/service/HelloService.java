package dip.day01.di.exam02.service;

import org.springframework.stereotype.Component;

@Component
public class HelloService implements IHelloService {

	/* (non-Javadoc)
	 * @see dip.day01.di.exam01.service.IHelloService#sayHello()
	 */
	@Override
	public String sayHello() {
		
		return "안녕하세요~";
	}

}
