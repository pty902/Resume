package dip.day01.di.exam02.service;

public interface IHelloService {

	/*public abstract*/ String sayHello();

}