package dip.day01.di.exam02.service;

import javax.annotation.Resource;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import dip.day01.di.exam02.log.MyLogger;

@Component
public class CalcService implements BeanNameAware {

//	@Autowired
//	@Qualifier("myConsoleLogger")
	@Resource(name="myNetworkLogger")
	private MyLogger logger; // = new MyFileLogger();//console, File, Network, Not
	
//	public void setLogger(MyLogger logger) {
//		this.logger = logger;
//	}	
	
	public int plus(int a,int b) {
		logger.log(a+"+"+b);
		return a + b;
	}

	@Override
	public void setBeanName(String beanname) {
		System.out.println("CalcService의 id는 "+beanname);
	}

}
