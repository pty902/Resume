package dip.day01.di.exam02.log;

public abstract class MyLogger {

	public abstract void log(String string) ;

}
