package dip.day01.aop.exam01;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import dip.day01.aop.exam01.service.HelloService;
import dip.day01.aop.exam01.service.IHelloService;

public class Main01 {

	public static void main(String[] args) {
		// 1. 스프링 빈 설정파일 작성(app.xml)
		// 2. 빈 클래스 작성(업무코드)
		// 3. 테스트 코드
		//헬로
		String configLocation="app.xml";//클래스 등록
		BeanFactory context = new FileSystemXmlApplicationContext(configLocation);
		IHelloService hs = context.getBean(IHelloService.class);
		System.out.println("hs의 실체:"+hs.getClass().getName());
		String r = hs.sayHello("박성용");
		System.out.println(r);
	}

}
