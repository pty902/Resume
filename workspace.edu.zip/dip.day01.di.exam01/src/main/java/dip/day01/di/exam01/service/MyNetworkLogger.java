package dip.day01.di.exam01.service;

import dip.day01.di.exam01.log.MyLogger;

public class MyNetworkLogger extends MyLogger {

	@Override
	public void log(String string) {
		System.out.println("Network Log"+string);

	}

}
