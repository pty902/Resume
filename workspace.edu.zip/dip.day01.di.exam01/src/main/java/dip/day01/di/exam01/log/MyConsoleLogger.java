package dip.day01.di.exam01.log;

public class MyConsoleLogger extends MyLogger {

	@Override
	public void log(String string) {
		System.out.println("Console Log:"+string);
	}

}
