package dip.day01.di.exam01;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import dip.day01.di.exam01.service.CalcService;
import dip.day01.di.exam01.service.IHelloService;

public class Main01 {

	public static void main(String[] args) {
		// 1. 스프링 빈 설정파일 작성(app.xml)
		// 2. 빈 클래스 작성(업무코드)
		// 3. 테스트 코드
		//헬로
		String configLocation="app.xml";//클래스 등록
		BeanFactory context = new FileSystemXmlApplicationContext(configLocation);
//		String configLocation="/beans.xml";//클래스 등록
//		BeanFactory context = new ClassPathXmlApplicationContext(configLocation);
//		IHelloService hs = context.getBean(IHelloService.class);
		IHelloService hs = (IHelloService) context.getBean("hello");
		String r = hs.sayHello();
		System.out.println(r);
		//////////////////////////////////
		CalcService cs = context.getBean(CalcService.class);
		int cr = cs.plus(2,3);
		System.out.println("2 + 3 = "+ cr); // 2 + 3 = 5
		
		CalcService cs2 = context.getBean(CalcService.class);
		System.out.println(cs==cs2);
		System.out.println(new String("a") == new String("a"));
	}

}
